package edu.ifes.ci.si.les.sgcsg.model;

import java.util.Date;

public class Voto {

	private Date data;

	private OpcaoDeVoto opcaoDeVoto;

	private Usuario usuario;

}
