package edu.ifes.ci.si.les.sgcsg.model;

import java.io.Serializable;
import lombok.*;
import javax.persistence.*;
import javax.validation.constraints.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = {"id"})
public class Usuario {
	private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(length = 255)
	@NotBlank(message = "Campo nome deve ser preenchido")
	@Size(min = 3, max = 255, message = "Campo nome deve ser maior que três caracteres")
	private String nome;
	
	@Column(length = 255)
	@NotBlank(message = "Campo email deve ser preenchido")
	@Size(min = 3, max = 255, message = "Campo email deve ser maior que três caracteres")
	private String email;

	@Column(length = 255)
	@NotBlank(message = "Campo senha deve ser preenchido")
	@Size(min = 3, max = 255, message = "Campo senha deve ser maior que três caracteres")
	private String senha;

	@Digits(integer=1, fraction=0, message = "Número do tipo de usuário deve ser preenchido com um valor inteiro")
	private tipoUsuario tipo;
}
