package edu.ifes.ci.si.les.sgcsg.model;

public class RespostaCampo {

	private String valor;

	private RespostaFormulario respostaFormulario;

	private CampoDeFormulario campoDeFormulario;

}
