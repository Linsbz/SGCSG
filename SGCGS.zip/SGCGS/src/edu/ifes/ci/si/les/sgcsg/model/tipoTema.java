package edu.ifes.ci.si.les.sgcsg.model;

public class tipoTema {

}
