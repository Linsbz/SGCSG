package edu.ifes.ci.si.les.sgcsg.model;

public class CampoDeFormulario {

	private Integer id;

	private String nome;

	private String tipo;

	private String valores;

	private Boolean campoObrigatorio;

	private Formulario formulario;

	private RespostaFormulario respostaFormulario;

}
