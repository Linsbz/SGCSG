package edu.ifes.ci.si.les.sgcsg.model;

public class Anuncio {

	private Integer id;

	private String titulo;

	private String link;

	private String imagemQuadrada;

	private String imagemHorizontal;

	private String imagemVertical;

	private Usuario usuario;

}
