package edu.ifes.ci.si.les.sgcsg.model;

public class AreasAnuncio {

	private Integer id;

	private String nome;

}
