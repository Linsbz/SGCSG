package edu.ifes.ci.si.les.sgcsg.model;

import java.util.Date;

public class CompraTema {

	private Integer id;

	private Date data;

	private Double valor;

	private Tema tema;

	private Usuario usuario;

}
