package edu.ifes.ci.si.les.sgcsg.model;

import java.util.Date;

public class PostagemNoticia {

	private Integer id;

	private Date dataInicio;

	private Date dataFim;

	private Boolean destaque;

	private Noticia noticia;

	private Usuario usuario;

}
