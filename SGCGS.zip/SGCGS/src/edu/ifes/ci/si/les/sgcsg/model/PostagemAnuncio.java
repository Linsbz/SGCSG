package edu.ifes.ci.si.les.sgcsg.model;

import java.util.Date;

public class PostagemAnuncio {

	private Integer id;

	private Date dataInicio;

	private Date dataFim;

	private Anuncio anuncio;

	private AreasAnuncio areasAnuncio;

}
