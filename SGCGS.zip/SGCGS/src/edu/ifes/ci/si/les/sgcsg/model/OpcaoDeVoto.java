package edu.ifes.ci.si.les.sgcsg.model;

public class OpcaoDeVoto {

	private Integer id;

	private String valor;

	private Enquete enquete;

}
