package edu.ifes.ci.si.les.sgcsg.model;

import lombok.*;

public class tipoUsuario {
    COMUM(0, "Usuário comum"),
	REDATOR(1, "Usuário administrador");
	ADMINISTRADOR(2, "Usuário administrador"),
	
	private int cod;
	private String descricao;
}
