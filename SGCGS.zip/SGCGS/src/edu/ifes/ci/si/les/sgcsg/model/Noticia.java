package edu.ifes.ci.si.les.sgcsg.model;

public class Noticia {

	private Integer id;

	private String titulo;

	private String subTitulo;

	private String conteudo;

	private String imagem;

	private String url;

	private Usuario usuario;

}
