package edu.ifes.ci.si.les.sgcsg.model;

import java.util.Date;

public class RespostaFormulario {

	private Integer id;

	private Date dataResposta;

	private Usuario usuario;

	private Formulario formulario;

}
