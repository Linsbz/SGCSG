package edu.ifes.ci.si.les.sgcsg.model;

public class Tema {

	private Integer id;

	private String nome;

	private tipoTema tipo;

	private Double valor;

	private Integer imagem;

}
